import React, { useEffect } from "react";
import "../Assets/App.css";

const FilterInput = ({ filterValue, setFilterValue }) => {
  useEffect(() => {}, [filterValue]);

  return (
    <div>
      <input
        type="text"
        id="search-yellow-pages"
        name="search"
        value={filterValue}
        placeholder="Filter By Name..."
        autocomplete="off"
        onChange={(e) => setFilterValue(e.target.value)}
      />
    </div>
  );
};

export default FilterInput;
